# NYC Airbnb Listing Segmentation — static site

A fully static, client-side site: an EDA/clustering report plus an interactive
segment predictor. No backend, no build step — just HTML/CSS/JS and one data
file. Everything (chart data, K-Means centroids, the scaler used to
standardize features, and a PCA projection) was pre-computed once from the
real dataset and baked into `assets/data.js`, so the predictor runs entirely
in the visitor's browser.

## Files
- `index.html` — page structure
- `assets/style.css` — styling
- `assets/app.js` — chart rendering + the in-browser predictor
- `assets/data.js` — pre-computed dataset/model artifacts (`window.SITE_DATA`)

## Deploy to GitHub Pages

1. Create a new GitHub repository (or use an existing one).
2. Copy these four files/folders into the repo root, preserving the
   `assets/` folder structure, then commit and push:
   ```
   git add index.html assets README.md
   git commit -m "Add clustering report site"
   git push
   ```
3. On GitHub: go to the repo's **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **Deploy from a branch**.
5. Pick the branch (usually `main`) and folder `/ (root)`, then **Save**.
6. GitHub will publish the site at:
   `https://<your-username>.github.io/<repo-name>/`
   (it can take a minute or two the first time.)

That's it — no build process, no server, nothing else to configure.

## Regenerating the data if you change the analysis

If you retrain the model or change preprocessing, `assets/data.js` needs to
be regenerated so the predictor stays in sync with whatever the report says.
The generation script (`build_all.py`, not included in the deployed site)
re-runs the same wrangling/feature-engineering steps as the notebook, fits
K-Means, and exports every chart's data plus the model artifacts as JSON,
which gets wrapped as `window.SITE_DATA = {...};` in `assets/data.js`.
