(function () {
  const D = window.SITE_DATA;

  const boroughColor = {
    Manhattan: '#0039A6',
    Brooklyn: '#FF6319',
    Queens: '#6CBE45',
    Bronx: '#B933AD',
    'Staten Island': '#808183'
  };
  const clusterColor = ['#4C6EF5', '#F76707', '#2F9E44', '#E64980', '#862E9C'];
  const roomTypeColor = {
    'Entire home/apt': '#0039A6',
    'Private room': '#F2A900',
    'Shared room': '#808183'
  };

  const clusterInfo = [
    {
      name: 'Everyday Manhattan homes',
      desc: 'Entire-home listings at a moderate price, spread mainly through Manhattan, with typical (not exceptional) booking activity.'
    },
    {
      name: 'Brooklyn private rooms',
      desc: 'Budget-friendly private rooms concentrated in Brooklyn — the largest segment, and the everyday alternative to renting a whole place.'
    },
    {
      name: 'High-turnover favorites',
      desc: 'Entire homes booked far more often than average, mostly in Brooklyn, run by hosts with just one or two listings — the platform\u2019s most active inventory.'
    },
    {
      name: 'Professional / high-end',
      desc: 'High-price Manhattan listings with long minimum stays and low personal turnover, run by hosts managing dozens of properties each.'
    },
    {
      name: 'Outer-borough budget rooms',
      desc: 'The cheapest segment overall — private rooms centered in Queens, with moderate booking activity.'
    }
  ];

  const fmtMoney = v => '$' + Math.round(v).toLocaleString();
  const fmtNum = v => (Math.round(v * 10) / 10).toLocaleString();

  /* ============ Hero stats ============ */
  document.getElementById('statRows').textContent = D.dataset_stats.n_rows.toLocaleString();
  document.getElementById('statFeatures').textContent = D.dataset_stats.n_features_final;
  document.getElementById('statSil').textContent = D.predictor.silhouette_score.toFixed(2);

  /* ============ Hero legend ============ */
  const heroLegend = document.getElementById('heroLegend');
  Object.keys(D.geo_scatter).forEach(b => {
    const el = document.createElement('span');
    el.innerHTML = `<span class="swatch" style="background:${boroughColor[b] || '#999'}"></span>${b}`;
    heroLegend.appendChild(el);
  });

  /* ============ Hero map ============ */
  const heroDatasets = Object.entries(D.geo_scatter).map(([b, pts]) => ({
    label: b,
    data: pts.lat.map((lat, i) => ({ x: pts.lon[i], y: lat })),
    backgroundColor: (boroughColor[b] || '#999') + 'CC',
    pointRadius: 1.7,
    pointHoverRadius: 1.7
  }));
  new Chart(document.getElementById('heroMap'), {
    type: 'scatter',
    data: { datasets: heroDatasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 1000, easing: 'easeOutQuad' },
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      scales: { x: { display: false }, y: { display: false } }
    }
  });

  /* ============ Shared light-theme chart options ============ */
  const gridLight = 'rgba(27,36,48,0.08)';
  const textDark = '#5B6472';
  function baseOptsLight(extra) {
    return Object.assign({
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: gridLight }, ticks: { color: textDark, font: { size: 11 } } },
        y: { grid: { color: gridLight }, ticks: { color: textDark, font: { size: 11 } }, beginAtZero: true }
      }
    }, extra || {});
  }

  /* ============ Price histogram ============ */
  new Chart(document.getElementById('chartPrice'), {
    type: 'bar',
    data: {
      labels: D.price_hist.labels,
      datasets: [{ data: D.price_hist.counts, backgroundColor: '#F2A900', barPercentage: 1, categoryPercentage: 1 }]
    },
    options: baseOptsLight({ scales: { x: { grid: { display: false }, ticks: { color: textDark, maxTicksLimit: 8 } }, y: { grid: { color: gridLight }, ticks: { color: textDark } } } })
  });

  /* ============ Borough counts ============ */
  new Chart(document.getElementById('chartBorough'), {
    type: 'bar',
    data: {
      labels: D.borough_counts.labels,
      datasets: [{ data: D.borough_counts.counts, backgroundColor: D.borough_counts.labels.map(l => boroughColor[l] || '#999') }]
    },
    options: baseOptsLight({ scales: { x: { grid: { display: false }, ticks: { color: textDark } }, y: { grid: { color: gridLight }, ticks: { color: textDark } } } })
  });

  /* ============ Room type share ============ */
  new Chart(document.getElementById('chartRoomType'), {
    type: 'doughnut',
    data: {
      labels: D.room_type_share.labels,
      datasets: [{ data: D.room_type_share.counts, backgroundColor: D.room_type_share.labels.map(l => roomTypeColor[l] || '#999'), borderColor: '#EDE7D6', borderWidth: 2 }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { color: textDark, font: { size: 11 }, boxWidth: 12 } } } }
  });

  /* ============ Avg price by borough ============ */
  new Chart(document.getElementById('chartAvgPrice'), {
    type: 'bar',
    data: {
      labels: D.avg_price_borough.labels,
      datasets: [{ data: D.avg_price_borough.values, backgroundColor: D.avg_price_borough.labels.map(l => boroughColor[l] || '#999') }]
    },
    options: baseOptsLight({ scales: { x: { grid: { display: false }, ticks: { color: textDark } }, y: { grid: { color: gridLight }, ticks: { color: textDark, callback: v => '$' + v } } } })
  });

  /* ============ Reviews histogram (log) ============ */
  new Chart(document.getElementById('chartReviews'), {
    type: 'bar',
    data: { labels: D.reviews_hist.labels, datasets: [{ data: D.reviews_hist.counts, backgroundColor: '#0039A6', barPercentage: 1, categoryPercentage: 1 }] },
    options: baseOptsLight({ scales: { x: { grid: { display: false }, ticks: { color: textDark, maxTicksLimit: 8 } }, y: { type: 'logarithmic', grid: { color: gridLight }, ticks: { color: textDark } } } })
  });

  /* ============ Availability histogram ============ */
  new Chart(document.getElementById('chartAvailability'), {
    type: 'bar',
    data: { labels: D.availability_hist.labels, datasets: [{ data: D.availability_hist.counts, backgroundColor: '#862E9C', barPercentage: 1, categoryPercentage: 1 }] },
    options: baseOptsLight({ scales: { x: { grid: { display: false }, ticks: { color: textDark, maxTicksLimit: 8 } }, y: { grid: { color: gridLight }, ticks: { color: textDark } } } })
  });

  /* ============ Price by room type (custom boxplot) ============ */
  (function renderBoxplot() {
    const container = document.getElementById('chartPriceBox');
    const stats = D.price_by_room_type;
    const types = Object.keys(stats);
    const globalMax = Math.max(...types.map(t => stats[t].max));
    types.forEach(t => {
      const s = stats[t];
      const pct = v => (v / globalMax) * 100;
      const row = document.createElement('div');
      row.className = 'box-row';
      row.innerHTML = `
        <div class="box-label">${t}</div>
        <div class="box-track">
          <div class="box-whisker" style="left:${pct(s.min)}%; width:${pct(s.max) - pct(s.min)}%;"></div>
          <div class="box-cap" style="left:${pct(s.min)}%;"></div>
          <div class="box-cap" style="left:${pct(s.max)}%;"></div>
          <div class="box-box" style="left:${pct(s.q1)}%; width:${pct(s.q3) - pct(s.q1)}%; background:${(roomTypeColor[t] || '#999')}22; border-color:${roomTypeColor[t] || '#999'};"></div>
          <div class="box-median" style="left:${pct(s.median)}%; background:${roomTypeColor[t] || '#F2A900'};"></div>
        </div>`;
      container.appendChild(row);
    });
    const axis = document.createElement('div');
    axis.className = 'box-axis';
    const ticks = [0, Math.round(globalMax / 2), Math.round(globalMax)];
    axis.innerHTML = `<div></div><div class="box-axis-track">${ticks.map(t => `<span style="left:${(t / globalMax) * 100}%;">$${t}</span>`).join('')}</div>`;
    container.appendChild(axis);
  })();

  /* ============ Correlation heatmap ============ */
  (function renderHeatmap() {
    const el = document.getElementById('heatmapTable');
    const cols = D.correlation.cols;
    const m = D.correlation.matrix;
    function cellColor(v) {
      const a = Math.min(Math.abs(v), 1);
      if (v >= 0) return `rgba(242,169,0,${0.12 + a * 0.55})`;
      return `rgba(0,57,166,${0.12 + a * 0.55})`;
    }
    let html = '<table><thead><tr><th></th>' + cols.map(c => `<th>${c.replace(/_/g, ' ')}</th>`).join('') + '</tr></thead><tbody>';
    cols.forEach((row, i) => {
      html += `<tr><th>${row.replace(/_/g, ' ')}</th>` + cols.map((c, j) => {
        const v = m[i][j];
        return `<td class="heat-cell" style="background:${cellColor(v)}">${v.toFixed(2)}</td>`;
      }).join('') + '</tr>';
    });
    html += '</tbody></table>';
    el.innerHTML = html;
  })();

  /* ============ Elbow chart ============ */
  new Chart(document.getElementById('chartElbow'), {
    type: 'line',
    data: {
      labels: D.elbow.k,
      datasets: [{ data: D.elbow.inertia, borderColor: '#0039A6', backgroundColor: '#0039A6', tension: 0.25, pointRadius: 3 }]
    },
    options: baseOptsLight({ scales: { x: { title: { display: true, text: 'k', color: textDark }, grid: { display: false }, ticks: { color: textDark } }, y: { grid: { color: gridLight }, ticks: { color: textDark } } } })
  });

  /* ============ Silhouette by k ============ */
  new Chart(document.getElementById('chartSilK'), {
    type: 'line',
    data: {
      labels: D.kmeans_tuning.map(r => r.k),
      datasets: [{
        data: D.kmeans_tuning.map(r => r.silhouette),
        borderColor: '#F2A900',
        backgroundColor: D.kmeans_tuning.map(r => r.k === 5 ? '#F2A900' : '#0039A6'),
        pointRadius: D.kmeans_tuning.map(r => r.k === 5 ? 6 : 3),
        tension: 0.25
      }]
    },
    options: baseOptsLight({ scales: { x: { title: { display: true, text: 'k', color: textDark }, grid: { display: false }, ticks: { color: textDark } }, y: { grid: { color: gridLight }, ticks: { color: textDark } } } })
  });

  /* ============ Model comparison ledger ============ */
  (function renderLedger() {
    const el = document.getElementById('modelLedger');
    const desc = {
      'KMeans (k=5)': 'Scales to all ~49k listings, five balanced, interpretable segments.',
      'Agglomerative (ward)': 'Comparable structure to K-Means, but O(n\u00b2) — fit on a 3,000-row sample.',
      'DBSCAN (tuned)': 'No fixed cluster count; labels sparse listings as noise instead of forcing a segment.'
    };
    Object.entries(D.model_comparison).forEach(([name, m]) => {
      const isWinner = name.startsWith('KMeans');
      const row = document.createElement('div');
      row.className = 'model-row' + (isWinner ? ' winner' : '');
      const noise = ('noise_pct' in m) ? ` &middot; ${Math.round(m.noise_pct * 100)}% noise` : '';
      row.innerHTML = `
        <div class="name">${name}${isWinner ? ' — selected' : ''}</div>
        <div class="desc">${desc[name] || ''}</div>
        <div class="metrics"><span>Silhouette <b>${m.silhouette.toFixed(3)}</b></span><span>Davies\u2013Bouldin <b>${m.davies_bouldin.toFixed(3)}</b>${noise}</span></div>`;
      el.appendChild(row);
    });
  })();

  document.getElementById('modelInsight').innerHTML =
    `K-Means was chosen with a silhouette score of <b>${D.predictor.silhouette_score.toFixed(3)}</b>, the best balance of the three. ` +
    `Agglomerative clustering with average or complete linkage can score higher on a small sample, but only by isolating a handful of outlier points into their own near-empty clusters — ward linkage trades a slightly lower score for five genuinely balanced groups. ` +
    `DBSCAN found real density structure but left over half the sampled points labeled as noise, which is informative for outlier detection but impractical as a segmentation for every listing.`;

  /* ============ Cluster PCA scatter ============ */
  const clusterDatasets = clusterInfo.map((info, idx) => {
    const pts = D.predictor.pca_sample.filter((_, i) => D.predictor.pca_sample_labels[i] === idx);
    return {
      label: info.name,
      data: pts.map(p => ({ x: p[0], y: p[1] })),
      backgroundColor: clusterColor[idx] + 'AA',
      pointRadius: 2.5
    };
  });
  new Chart(document.getElementById('chartClusterScatter'), {
    type: 'scatter',
    data: { datasets: clusterDatasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom', labels: { color: textDark, font: { size: 11 }, boxWidth: 10 } } },
      scales: {
        x: { title: { display: true, text: 'PC1', color: textDark }, grid: { color: gridLight }, ticks: { color: textDark } },
        y: { title: { display: true, text: 'PC2', color: textDark }, grid: { color: gridLight }, ticks: { color: textDark } }
      }
    }
  });

  /* ============ Cluster profile cards ============ */
  (function renderClusterGrid() {
    const el = document.getElementById('clusterGrid');
    clusterInfo.forEach((info, idx) => {
      const size = D.predictor.cluster_sizes[idx];
      const pct = Math.round((size / D.dataset_stats.n_rows) * 100);
      const means = D.predictor.cluster_profile_means[idx];
      const card = document.createElement('div');
      card.className = 'cluster-card';
      card.innerHTML = `
        <div class="bar" style="background:${clusterColor[idx]}"></div>
        <h4>${info.name}</h4>
        <div class="size">${size.toLocaleString()} listings &middot; ${pct}%</div>
        <p>${info.desc}</p>
        <p style="margin-top:8px; color:var(--muted-dark);">Avg. ${fmtMoney(means.price)}/night &middot; ${fmtNum(means.number_of_reviews)} reviews</p>`;
      el.appendChild(card);
    });
  })();

  /* ================= PREDICTOR ================= */
  const P = D.predictor;
  const boroughSel = document.getElementById('inBorough');
  const roomSel = document.getElementById('inRoomType');
  P.neighbourhood_groups.forEach(b => {
    const o = document.createElement('option'); o.value = b; o.textContent = b; boroughSel.appendChild(o);
  });
  P.room_types.forEach(r => {
    const o = document.createElement('option'); o.value = r; o.textContent = r; roomSel.appendChild(o);
  });
  boroughSel.value = 'Manhattan';
  roomSel.value = 'Entire home/apt';

  document.getElementById('inPrice').value = Math.round(P.medians.price);
  document.getElementById('inMinNights').value = Math.round(P.medians.minimum_nights);
  document.getElementById('inReviews').value = Math.round(P.medians.number_of_reviews);
  document.getElementById('inReviewsMonth').value = P.medians.reviews_per_month;
  document.getElementById('inHostListings').value = Math.round(P.medians.calculated_host_listings_count);
  document.getElementById('inAvailability').value = Math.round(P.medians.availability_365);

  // Background scatter for predictor map (faint, colored by cluster)
  const predictorBgDatasets = clusterInfo.map((info, idx) => {
    const pts = P.pca_sample.filter((_, i) => P.pca_sample_labels[i] === idx);
    return {
      label: info.name,
      data: pts.map(p => ({ x: p[0], y: p[1] })),
      backgroundColor: clusterColor[idx] + '55',
      pointRadius: 2
    };
  });
  const userDataset = { label: 'Your listing', data: [], backgroundColor: '#F3EFE2', borderColor: '#0D1B2A', borderWidth: 2, pointRadius: 7, pointHoverRadius: 7 };

  const predictorChart = new Chart(document.getElementById('predictorMap'), {
    type: 'scatter',
    data: { datasets: [...predictorBgDatasets, userDataset] },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      scales: { x: { display: false }, y: { display: false } }
    }
  });

  function predict() {
    const borough = boroughSel.value;
    const roomType = roomSel.value;
    const price = parseFloat(document.getElementById('inPrice').value) || 0;
    const minNights = parseFloat(document.getElementById('inMinNights').value) || 1;
    const reviews = parseFloat(document.getElementById('inReviews').value) || 0;
    const reviewsMonth = parseFloat(document.getElementById('inReviewsMonth').value) || 0;
    const hostListings = Math.max(parseFloat(document.getElementById('inHostListings').value) || 1, 1);
    const availability = Math.min(Math.max(parseFloat(document.getElementById('inAvailability').value) || 0, 0), 365);

    const latlon = P.borough_latlong[borough];
    const pricePerReview = price / (reviews + 1);
    const reviewsPerListing = reviews / hostListings;
    const availabilityRatio = availability / 365;

    const rawFeatures = {
      latitude: latlon.lat,
      longitude: latlon.lon,
      price: price,
      minimum_nights: minNights,
      number_of_reviews: reviews,
      reviews_per_month: reviewsMonth,
      calculated_host_listings_count: hostListings,
      availability_365: availability,
      price_per_review: pricePerReview,
      reviews_per_listing: reviewsPerListing,
      availability_ratio: availabilityRatio
    };
    P.cat_encoded_columns.forEach(col => {
      let val = 0;
      if (col.startsWith('neighbourhood_group_') && col.slice('neighbourhood_group_'.length) === borough) val = 1;
      if (col.startsWith('room_type_') && col.slice('room_type_'.length) === roomType) val = 1;
      rawFeatures[col] = val;
    });

    const x = P.feature_names.map(f => rawFeatures[f]);
    const xScaled = x.map((v, i) => (v - P.scaler_mean[i]) / P.scaler_scale[i]);

    let bestCluster = 0, bestDist = Infinity;
    P.centroids.forEach((centroid, idx) => {
      let dist = 0;
      centroid.forEach((c, i) => { const d = xScaled[i] - c; dist += d * d; });
      if (dist < bestDist) { bestDist = dist; bestCluster = idx; }
    });

    // Project onto PCA space for the map
    const pc1 = xScaled.reduce((sum, v, i) => sum + (v - P.pca_mean[i]) * P.pca_components[0][i], 0);
    const pc2 = xScaled.reduce((sum, v, i) => sum + (v - P.pca_mean[i]) * P.pca_components[1][i], 0);

    userDataset.data = [{ x: pc1, y: pc2 }];
    userDataset.borderColor = clusterColor[bestCluster];
    predictorChart.update();

    const info = clusterInfo[bestCluster];
    const means = P.cluster_profile_means[bestCluster];
    document.getElementById('resultPlaceholder').style.display = 'none';
    const body = document.getElementById('resultBody');
    body.style.display = 'block';
    body.innerHTML = `
      <div class="result-tag"><span class="dot" style="background:${clusterColor[bestCluster]}"></span>${info.name}</div>
      <div class="desc">${info.desc}</div>
      <table class="compare-table">
        <thead><tr><th></th><th>Your listing</th><th>Segment average</th></tr></thead>
        <tbody>
          <tr><td>Price / night</td><td>${fmtMoney(price)}</td><td>${fmtMoney(means.price)}</td></tr>
          <tr><td>Minimum nights</td><td>${minNights}</td><td>${fmtNum(means.minimum_nights)}</td></tr>
          <tr><td>Total reviews</td><td>${reviews}</td><td>${fmtNum(means.number_of_reviews)}</td></tr>
          <tr><td>Availability (days)</td><td>${availability}</td><td>${fmtNum(means.availability_365)}</td></tr>
        </tbody>
      </table>`;
  }

  document.getElementById('btnPredict').addEventListener('click', predict);
})();
